from flask import Flask, render_template, request, jsonify
import random
from datetime import datetime

app = Flask(__name__)

responses = {
    "hi": ["Hello!", "Hi there! How can I assist you today? "],
    "how are you": ["I'm just a bot, but I'm happy to help!", "Doing great! What about you?"],
    "admission": [
        "Admissions are open! You can apply through our official portal.",
        "To apply for admission, visit the university website and click 'Apply Now'."
    ],
    "courses": [
        "We offer BS in Data Science, Artificial Intelligence, Software Engineering, and more!",
        "Our top programs include Computer Science, Cybersecurity, and Business Analytics."
    ],
    "fee": ["The semester fee is around $1200", "It varies by program, but approx. $1000 - $1500."],
    "deadline": ["The application deadline is April 30th, 2025. Don't miss it!"],
    "contact": ["You can contact us at admission@university.edu or call (123)-456-7890"],
    "library": ["Our digital library is open 24/7!", "We have over 10,000 books and journals online."],
    "thank you": ["You're welcome!", "Anytime!"],
    "bye": ["Goodbye!", "See you later! Take care!"]
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json['message'].lower()
    response = "Hmm, I didn't get that. Can you please rephrase?"

    # Check if the user input contains any known keywords
    for key in responses:
        if key in user_input:
            response = random.choice(responses[key])
            break

    # Add timestamp for response
    time = datetime.now().strftime("%H:%M")
    return jsonify({'response': response, 'time': time})

if __name__ == '__main__':
    app.run(debug=True)
