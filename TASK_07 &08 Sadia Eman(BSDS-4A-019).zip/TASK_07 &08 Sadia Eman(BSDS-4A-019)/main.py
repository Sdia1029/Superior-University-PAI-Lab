from flask import Flask, render_template, jsonify
import requests
from config import NEWS_API_KEY

app = Flask(__name__)
def get_news():
    url = f"https://newsapi.org/v2/top-headlines?country=us&apiKey={NEWS_API_KEY}"
    response = requests.get(url)
    data = response.json()
    return data.get("articles", [])
@app.route('/news', methods=['GET'])
def news():
    articles = get_news()
    return jsonify(articles)

@app.route('/')
def home():
    articles = get_news()
    return render_template('index.html', articles=articles)

if __name__ == '__main__':
    app.run(debug=True)
